﻿using Dtail_EasyCollector;
using System.Text.RegularExpressions;

var input = new HashSet<string>();
input = GetInputFromConsole(
    "Please enter list of skus", "end");

Console.WriteLine("Path for the source directory:");
var sourcePath = Console.ReadLine();
var sourceFiles = Directory
    .EnumerateFiles(sourcePath, "*", new EnumerationOptions()
    {
        IgnoreInaccessible = true,
        RecurseSubdirectories = true
    })
    .ToList();

var collectedAssets = GetGarments(input, sourceFiles);
var combinedPaths = CollectPathsInList(collectedAssets);

MoveFiles(combinedPaths);

void MoveFiles(List<string> paths)
{
    Console.WriteLine("Please provide output folder:");
    var outputFolder = Console.ReadLine();

    var currentTime = $"({DateTime.UtcNow:yyyy-MM-dd; HH.mm})";
    var mainFolderName = "\\CollectedFiles" + currentTime;

    outputFolder += mainFolderName;

    Parallel.ForEach(paths, path =>
    {
        var folderName = path.Split("\\")[^3];
        var fileName = Path.GetFileName(path);
        if (fileName.Contains("Reduced"))
        {
            fileName = fileName.Replace("_Reduced", "", StringComparison.OrdinalIgnoreCase);
        }

        var newDirectory = Path.Combine(outputFolder, folderName);
        try
        {
            if (!Directory.Exists(newDirectory))
            {
                Directory.CreateDirectory(newDirectory);
            }
        }
        catch { }

        var newFile = Path.Combine(newDirectory, fileName);
        if (!File.Exists(newFile))
        {
            File.Copy(path, newFile, true);
        }
    });
}

List<string> CollectPathsInList(Dictionary<string, Garment> collectedAssets)
{
    List<string> combinedPaths = new();
    foreach (var (_, value) in collectedAssets)
        foreach (var property in typeof(Garment).GetProperties())
        {
            var assetPath = property.GetValue(value);

            switch (assetPath)
            {
                case null:
                    continue;
                case string list:
                    combinedPaths.Add(list);
                    break;
                default:
                    {
                        if (assetPath.GetType() == typeof(List<string>))
                            combinedPaths.AddRange((List<string>)assetPath);
                        break;
                    }
            }
        }

    return combinedPaths;
}

Dictionary<string, Garment> GetGarments(
    IEnumerable<string> input,
    List<string> sourceFiles)
{
    Dictionary<string, Garment> dictionary = new();

    foreach (var garment in input)
    {
        foreach (var path in sourceFiles.Where(path => path.Contains(garment)))
        {
            if (dictionary.ContainsKey(garment) == false)
            {
                dictionary.Add(garment, new Garment());
            }

            AddAssetToTheCorrectPlace(
                dictionary[garment],
                path,
                garment);
        }
    }

    return dictionary;
}

void AddAssetToTheCorrectPlace(Garment garment, string path, string currentGarment)
{
    var validDiffuseTexture = new Regex(@"T_[A-z0-9]{9}_D\.jpg");
    var validNormalTexture = new Regex(@"T_[A-z0-9]{9}_[A-z0-9]{2}-[A-z0-9]{2}_N\.jpg");
    var validMetalnessTexture = new Regex(@"T_[A-z0-9]{9}_M\.jpg");
    var validRoughnessTexture = new Regex(@"T_[A-z0-9]{9}_R\.jpg");

    var validHangingMesh = new Regex(@"SM_[A-z0-9]{9}_[A-z0-9]{4}_0_Reduced\.(obj|fbx)");
    var validHollowBodyMesh = new Regex(@"SM_[A-z0-9]{9}_[A-z0-9]{2}-[A-z0-9]{2}_0_Reduced\.(obj|fbx)");
    var validSquareFoldMesh = new Regex(@"SM_[A-z0-9]{9}_[A-z0-9]{4}_0_Reduced\.(obj|fbx)");

    if (validDiffuseTexture.IsMatch(path))
    {
        garment.DiffuseTexture = path;
    }
    else if (validNormalTexture.IsMatch(path))
    {
        garment.NormalTexture = path;
    }
    else if (validMetalnessTexture.IsMatch(path))
    {
        garment.MetalnessTexture = path;
    }
    else if (validRoughnessTexture.IsMatch(path))
    {
        garment.RoughnessTexture = path;
    }
    else if (validHangingMesh.IsMatch(path)
        && !path.Contains("SF00", StringComparison.OrdinalIgnoreCase))
    {
        garment.HangingMesh = path;
    }
    else if (validHollowBodyMesh.IsMatch(path))
    {
        garment.HollowBodyMesh = path;
    }
    else if (validSquareFoldMesh.IsMatch(path)
        && path.Contains("SF00", StringComparison.OrdinalIgnoreCase))
    {
        garment.SquareFoldMesh = path;
    }
}

HashSet<string> GetInputFromConsole(
    string messageToDisplay,
    string commandToEnd)
{
    Console.WriteLine(messageToDisplay);
    Console.WriteLine($"In order to end type: {commandToEnd}");

    string consoleInput;
    var validList = new HashSet<string>();

    while ((consoleInput = Console.ReadLine()) != commandToEnd)
    {
        if (!string.IsNullOrWhiteSpace(consoleInput))
        {
            validList.Add(consoleInput);
        }
    }

    return validList;
}